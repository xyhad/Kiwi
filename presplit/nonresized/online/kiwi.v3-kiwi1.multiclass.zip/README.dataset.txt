# kiwi > kiwi1
https://universe.roboflow.com/newworkplace/kiwi-ucv1a

Provided by a Roboflow user
License: CC BY 4.0

